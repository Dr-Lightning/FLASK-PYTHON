from flask import Flask, render_template, flash, redirect, url_for

from app.forms import LoginForm
from app.forms import AddUser

app = Flask(__name__)
app.config['SECRET_KEY'] = 'you-will-never-guess'


@app.route('/')
@app.route('/index')
def index():
    user = {'username': 'Miguel'}
    posts = [
        {
            'author': {'username': 'John'},
            'body': 'Beautiful day in Portland!'
        },
        {
            'author': {'username': 'Susan'},
            'body': 'The Avengers movie was so cool!'
        }
    ]
    return render_template('index.html', title='Home', user=user, posts=posts)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        flash('Login requested for user {}, remember_me={}'.format(
            form.username.data, form.remember_me.data))
        return redirect(url_for('index'))
    return render_template('login.html', title='Sign In', form=form)


@app.route('/register', methods=['GET', 'POST'])
def register():
    register = AddUser()
    if register.validate_on_submit():
        flash('Login requested for user {}, ps_number={}'.format(
            register.username.data, register.psnumber.data))
        return redirect(url_for('index'))
    return render_template('adduser.html', title='Sign In', register=register)


if __name__ == '__main__':
    app.run(debug=True)