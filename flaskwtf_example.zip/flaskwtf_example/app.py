from flask import Flask, render_template, redirect, url_for, flash
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, TextAreaField, RadioField, SelectField,IntegerField, validators
from wtforms.validators import InputRequired

app = Flask(__name__)
app.config['SECRET_KEY'] = 'Thisisasecret!'

class MyForm(FlaskForm):
    email = StringField('Email', validators=[InputRequired('Email Id is required')])
    username = StringField('Username', validators=[InputRequired('Username is required')])
    ps_number = IntegerField('PS No', [validators.data_required('Ps Number is required')])
    password = PasswordField('Password', [
        validators.DataRequired('Password is required'), validators.length(min=8, max=16, message='Password must be between 8 and 16'),
        validators.EqualTo('confirm', message='Passwords must match')
    ])
    confirm = PasswordField('Confirm Password')
    selects = SelectField('Role', choices=[('admin', 'admin'), ('superuser', 'superuser'), ('guest', 'guest')])

class addServer(FlaskForm):
    servername = StringField('Servername', validators=[InputRequired('Required')])
    Ipaddress = StringField('IP Address', validators=[InputRequired('Required')])
    username = StringField('Server Username', validators=[InputRequired('Required')])
    password = PasswordField('Password', validators=[InputRequired('Email Id is required')])


class LoginForm(FlaskForm):
    ps_number = IntegerField('PS No', validators=[InputRequired('Email Id is required')])
    password = PasswordField('Password', validators=[InputRequired('Email Id is required')])


@app.route('/')
@app.route('/index')
def index():
   return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        flash('Login requested for user {}, remember_me={}'.format(
            form.username.data, form.remember_me.data))
        return redirect(url_for('index'))
    return render_template('login.html', form=form)


@app.route('/thankyou')
def thankyou():
    return render_template('results.html')


@app.route('/adduser', methods=['GET', 'POST'])
def form():
    form = MyForm()
    if form.validate_on_submit():
        return redirect(url_for('thankyou'))
    return render_template('form.html', form=form)

@app.route('/addserver', methods=['GET', 'POST'])
def addserver():
    form = addServer()

    if form.validate_on_submit():
        return redirect(url_for('index'))
    return render_template('addserver.html', form=form)


if __name__ == '__main__':
    app.run(debug=True)