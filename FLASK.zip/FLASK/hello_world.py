from flask import Flask
app = Flask(__name__)


@app.route('/')
def index():
    return '<h1>Hello World</h1>'


@app.route('/about')
def about_page():
    return "<h1>You are in the about Section</h1>"


@app.route('/user/<name>')
def user_page(name):
    if name[-1] != 'y':
        name += 'y'
    else:
        name = name[:-1] + 'ed'
    return "<h1>Welcome, {} !</h1>".format(name)


if __name__ == '__main__':
    app.run(debug=True)